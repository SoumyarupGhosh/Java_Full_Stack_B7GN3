package com.wellsfargo.batch7.group3.model;

public class Attributes {
	
	public static final String GET_ACCT_BALANCE = "select AVLBL_BAL from CUST_ACCT where CUST_ACCT_NUM = ?";

}
