package com.wellsfargo.batch7.group3.model;

public class IBSException extends Exception{

		public IBSException(String message) {
			super(message);
		}
}
