package com.wellsfargo.batch7.group3.exception;

public class IBSException extends Exception{

		public IBSException(String message) {
			super(message);
		}
}
